public interface CommandFactory
{
	public Command createCommand();
}
